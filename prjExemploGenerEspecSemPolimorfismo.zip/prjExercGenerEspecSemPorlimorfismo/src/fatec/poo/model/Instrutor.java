package fatec.poo.model;

/**
 *
 * @Matheusvandowski
 */
public class Instrutor extends Pessoa{
    
    private int identificacao;
    private String areaAtuacao;
    
    public Instrutor(int id, String n, String tf ){
        super(n, tf);
        identificacao = id;
    }
    
    public void setAreaAtualizacao(String a){
        areaAtuacao = a; 
    }
    
    public String getAreaAtualizacao(){
        return(areaAtuacao);
    }
    
    public int getIdentificacao(){
        return(identificacao);
    }
    
}
