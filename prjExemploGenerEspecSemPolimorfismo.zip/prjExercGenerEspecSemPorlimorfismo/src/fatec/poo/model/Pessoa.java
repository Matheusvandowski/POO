
package fatec.poo.model;

/**
 *
 * @Matheusvandowski
 */
public class Pessoa {
    
   private String nome;
   private String telefone;
   
   public Pessoa(String n, String tf ){
       nome = n;
       telefone = tf;
   }
    
   public String getNome(){
       return(nome);
   }
   
   public String getTelefone(){
       return(telefone);
   }
   
}
