
package fatec.poo.model;

/**
 *
 * @Matheusvandowski 
 */
public class Cliente extends Pessoa{
    private String cpf;
    private double peso;
    private double altura;
    
    public Cliente(String c, String n, String tf){
        super(n,tf);
        cpf = c;
    }
    
    public void setPeso( double p){
        peso = p;
    }
    
    public void setAltura( double a){
        altura = a; 
    }
    
    public String getCpf(){
        return(cpf);
    }

    public double getAltura() {
        return altura;
    }

    public double getPeso() {
        return peso;
    }   
    
    
    
}
