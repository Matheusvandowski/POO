
import fatec.poo.model.Cliente;
import fatec.poo.model.Instrutor;
import java.text.DecimalFormat;


/**
 *
 * @Matheusvandowski 
 */
public class Aplic {

    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat(".00");
        Instrutor objInstr = new Instrutor(484827, "Alberto Rodriguez","15 9999-8888" );
        Cliente objClient = new Cliente("47622938419", "Lucas Moura", "19 4002-8922");
        
        objInstr.setAreaAtualizacao("Fisioteria");
        objClient.setPeso(72.00);
        objClient.setAltura(1.75);
        
        System.out.println("Identificacao: " + objInstr.getIdentificacao());
        System.out.println("Nome: " + objInstr.getNome());
        System.out.println("Telefone: " + objInstr.getTelefone());
        System.out.println("Area Atuacao: " + objInstr.getAreaAtualizacao());
        
        System.out.println("CPF: " + objClient.getCpf());
        System.out.println("Nome: " + objClient.getNome());
        System.out.println("Teleonfe: " + objClient.getTelefone());
        System.out.println("Peso: " + objClient.getAltura());
        System.out.println("Altura: " + objClient.getAltura());
        
    }
    
    
}
