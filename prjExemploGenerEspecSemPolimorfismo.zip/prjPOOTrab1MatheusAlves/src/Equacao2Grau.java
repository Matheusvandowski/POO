
/**
 *
 * @author Matheus Alves 
 */
public class Equacao2Grau {
    private double coef_A;
    private double coef_B;
    private double coef_C;
    private double numero;
           
    
   public Equacao2Grau(double coefA,double coefB,double coefC){
       
       coef_A = coefA;
       coef_B = coefB;
       coef_C = coefC;
   }
    
    
    public double calcDelta( ){
        numero = (coef_B*coef_B) - (4*coef_A*coef_C);
        return( numero);
    }
    
            
    public double calcRaiz(double numero){
        double a;      
        double b; 
        a =  ((coef_B * -1) + Math.sqrt(numero)) / (2* coef_A) ;
        b = ((coef_B * -1) - Math.sqrt(numero)) / (2* coef_A);
        
        if(numero < 0)
        return -1;
        
        else
        if(numero == 0)
            return(a);
        else
        if(numero > 0)
            return(a);           
        
        if(numero >0);
            return(b);
    }
        
    public String exibeEquacao(){
        
        String equacao = "";
        if(coef_A==1)
            equacao="X²";
        else
            equacao=(int)coef_A+"X²";
       if(coef_B>0)
        equacao +="+"+(int)coef_B+"X ";
       else
           equacao +=(int)coef_B+"X ";
       if(coef_C>0)
        equacao +="+"+(int)coef_C;
       else
           equacao +=(int)coef_C;
        return equacao;
    }
}
