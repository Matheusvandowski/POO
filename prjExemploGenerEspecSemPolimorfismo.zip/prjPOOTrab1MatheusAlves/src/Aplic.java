

/**
 *
 * @Matheus Avles
 */
public class Aplic {

   
    public static void main(String[] args) {
        
        double coefA, coefB, coefC;
        
        Scanner entrada = new Scanner(System.in);      
        System.out.println("Digite o Coeficiente A: ");
        coefA = entrada.nextDouble();
        System.out.println("Digite o Coeficiente B: ");
        coefB = entrada.nextDouble();
        System.out.println("Digite o Coeficiente C: ");
        coefC = entrada.nextDouble();
        
        Equacao2Grau objEquacao = new Equacao2Grau(coefA, coefB, coefC);
        
        
        
        
    }
    
}
