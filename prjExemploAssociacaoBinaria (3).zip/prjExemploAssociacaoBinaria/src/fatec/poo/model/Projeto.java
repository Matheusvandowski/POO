
package fatec.poo.model;

/**
 *
 * @Matheusvandowski
 */
public class Projeto {
    private int codigo;
    private String descricao;
    private String dtInicio;
    private String dtTermino;
    private Funcionario[] funcionarios;
    private int numFunc;
    
        
    public Projeto(int codigo, String descricao){
        this.codigo = codigo;
        this.descricao = descricao;
        funcionarios = new Funcionario [5];
        numFunc = 0;
    }
    
    public void setDtInicio(String dtInic){
        dtInicio = dtInic;
    }
    
    public void setDtTermino(String dtTerm){
        dtTermino = dtTerm;
    }
    
    public int getCodigo(){
        return(codigo);
    }
    
    public String getDescricao(){
        return(descricao);
    }
    
    public String getDtInicio(){
        return(dtInicio);
    }
    
    public String getDtTermino(){
     
       return(dtTermino);
    }
    
    public void addFuncionarios(Funcionario f){
        funcionarios[numFunc] = f;
        numFunc++;
    }
    
    public void listarFuncionarios(){
        System.out.println("Código: " + codigo);
        System.out.println("\nDescrição: " + descricao);
        System.out.println("\nData Início: " + dtInicio);        
        System.out.println("\nData Termino: " + dtTermino);
        System.out.println("\nQtde. de Funcionarios: " + numFunc); 
        System.out.println("\n\nRegistro\tNome\tCargo");
        for(int i = 0; i< numFunc;i++ ){
        System.out.println(funcionarios[i].getRegistro() + "\t" + funcionarios[i].getNome() + "\t" + funcionarios[i].getCargo());
    }
                
       System.out.println("\n\t");
    }
}
