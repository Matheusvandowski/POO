package fatec.poo.model;

/**
 *
 * @author Mvandowski
 */
public class FuncionarioHorista extends Funcionario {
    private double valHorTrab;
    private int qtdHorTrab; 
    
    public FuncionarioHorista( int r, String n, String dt, double vht){
        super( r, n, dt);
        valHorTrab = vht;
    }
    
    public void setQtdHorTrab(int qht){
        qtdHorTrab = qht;
    }
    
    public double calcSalBruto(){
        return(valHorTrab*qtdHorTrab);
    }
    
    public double calcGratificacao(){
        return(calcSalBruto()*0.075);
    }
    
    @Override
    public double calcSalLiquido(){
        return(calcSalBruto()+calcGratificacao()-calcDesconto());
    }
    
}
