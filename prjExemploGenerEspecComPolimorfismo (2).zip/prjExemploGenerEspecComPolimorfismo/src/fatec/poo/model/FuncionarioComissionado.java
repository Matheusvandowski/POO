
package fatec.poo.model;

/**
 *
 * @Matheusvandowski
 */
public class FuncionarioComissionado extends Funcionario {
    private double salBase;
    private double taxaComissao;
    private double totalVendas = 0;
       
    
    public FuncionarioComissionado(int r, String n, String dt, double tc ){
        super(r,n,dt);
        taxaComissao = tc/100;
    }
    
    public void setSalBase(double sb){
        salBase = sb;
    }
    
    public double getSalBase(){
    return(salBase);
}
    
   public double getTaxaComissao(){
       return(taxaComissao);
   }
   
   public double addVendas(double v){
       totalVendas = totalVendas + v; 
       return(totalVendas);
       
   }
   
   public double getTotalVendas(){
       return(totalVendas);
   }
   
   public double calcSalBruto(){
       return(salBase + (taxaComissao * totalVendas) );
   }
    
   public double calcGratificacao(){
       if(totalVendas<= 5000)
       return(0);
       else 
           if(totalVendas<=10000)
               return(0.03*calcSalBruto());
           else
               return(0.05*calcSalBruto());
       
   }
     
   @Override
   public double calcSalLiquido(){
        return(calcSalBruto() - calcDesconto() + calcGratificacao());
    }
          
}

