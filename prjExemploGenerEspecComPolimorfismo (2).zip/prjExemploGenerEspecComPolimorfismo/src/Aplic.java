
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;


/**
 *
 * @author Mvandowski 
 */
public class Aplic {

    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010,"Pedro Calvo","07/09/1985", 15.00);
        FuncionarioMensalista funcMen = new FuncionarioMensalista(2013,"Pedro Cabeludo", "20/08/2006", 1450.00);
        
        funcHor.setQtdHorTrab(44*4);
        funcHor.setCargo("Auxiliar Produção");
        funcMen.setNumSalMin(5);
        funcMen.setCargo("Gerente");
        
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salario Bruto: " + funcHor.calcSalBruto());
        System.out.println("Valor Desconto: " + funcHor.calcDesconto());
        System.out.println("Salario Liquido: " + funcHor.calcSalLiquido());
        System.out.println("Valor Gratificacao: " + funcHor.calcGratificacao());
        
        System.out.println("\n ");
        
        System.out.println("Cargo: " + funcMen.getCargo());
        System.out.println("Salario Bruto: " + funcMen.calcSalBruto());
        System.out.println("Valor Desconto: " + funcMen.calcDesconto());
        System.out.println("Salario Liquido: " + funcMen.calcSalLiquido());
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(2024, "Calvo Guedes", "09/09/2009",10.0);
        
        funcCom.setCargo("Vendedor");
        funcCom.setSalBase(3400.00);
        funcCom.addVendas(1000.00);
        funcCom.addVendas(2000.00);
        funcCom.addVendas(3000.00);
        funcCom.addVendas(1000.00);
        
        System.out.println("\nCargo: " + funcCom.getCargo());
        System.out.println("Salario base: " + funcCom.getSalBase());
        System.out.println("Total Vendas: " + funcCom.getTotalVendas());
        System.out.println("Valor taxa comissão: " + funcCom.getTaxaComissao());
        System.out.println("Valor Desconto: " + funcCom.calcDesconto());
        System.out.println("Salário Bruto: " + funcCom.calcSalBruto());
        System.out.println("Valor de Gratificacao: " + funcCom.calcGratificacao());
        System.out.println("Salario Liquido: " + funcCom.calcSalLiquido());
        
    }
    
}
