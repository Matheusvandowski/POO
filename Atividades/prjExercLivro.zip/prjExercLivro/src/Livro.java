

/**
 *
 * @author Matheus Alves
 */
public class Livro {
    
    private int identificacao;
    private String titulo ;
    private boolean situacao = false;
    private double valMultaDiaria;
    
    public void setIdentif(int id){
        identificacao = id;
    }
    
    public void setTitulo(String title){
        titulo = title;
    }
    
    
    public void setValorMulta( double valMulta){
        valMultaDiaria = valMulta;        
    }
    
    public int getIdentif(){
        return( identificacao);
    }
    
    public String getTitulo(){
        return( titulo);
    }
    
    public boolean getSituacao(){
        return(situacao);
    }
    
    public void emprestar(){
        situacao = true;
    }
    
    public double devolver(int dias){
         situacao = false;
         return( dias * valMultaDiaria);        
        
    }
    
    
    
    
  
}
