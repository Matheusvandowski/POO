
import java.util.Scanner;
import java.text.DecimalFormat;


/**
 *
 * @author Matheus Alves 
 */
public class Aplic {

    
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in); 
        
        int opcao, id, day; 
        String title;
        double valMulta;
        
        System.out.print("Digite identificação do livro desejado: ");
        id = entrada.nextInt();
        
        System.out.print("Digite o nome do Titulo: ");
        title = entrada.next();
        
        System.out.print("Digite o valor diario da multa: ");
        valMulta = entrada.nextDouble();
        
                   
        Livro objLivro = new Livro();
        
        objLivro.setIdentif(id);
        objLivro.setTitulo(title);
        objLivro.setValorMulta(valMulta);

        
         do{
             System.out.println("\n1 - Consultar Livro");
             System.out.println("2 - Emprestar Livro");
             System.out.println("3 - Devolver Livro ");
             System.out.println("4 - Sair");
             System.out.print("\n\tDigite a opcao: ");
             
             opcao = entrada.nextInt();   
        
            switch(opcao) {          
                case 1: System.out.println("Nome do Livro: " + objLivro.getTitulo() + "\nIdentificacao do Livro " + objLivro.getIdentif() );
                
                        if(objLivro.getSituacao()==true)
                            System.out.println("\nLivro Emprestado");
                            
                        else
                            System.out.println("\nLivro Disponível");
                        break;
             
                case 2: System.out.println("Nome do Livro: " + objLivro.getTitulo() + "\nIdentificacao do Livro " + objLivro.getIdentif() );
                        if(objLivro.getSituacao()==true)
                            System.out.println("\nLivro Indisponível, sorry");
                            
                        else{
                            objLivro.emprestar();
                            System.out.println("\nParabéns, livro reservado para você");}
                        break;
             
                case 3: System.out.println("Nome do Livro: " + objLivro.getTitulo() + "\nIdentificacao do Livro" + objLivro.getIdentif() );
                        if(objLivro.getSituacao()==false)
                            System.out.println("\nVocê não esta em posse desse livro");
                        
                        else{                            
                            System.out.print("Digite o numero de dias de atraso de entrega: ");
                             day = entrada.nextInt();
                            System.out.println("\nParabéns, você acabou de devolver o livro, valor pago: " + objLivro.devolver(day));}
                            
                        break; 
                        
              
        
         }
        }while (opcao < 4);
       
    }
    
}
