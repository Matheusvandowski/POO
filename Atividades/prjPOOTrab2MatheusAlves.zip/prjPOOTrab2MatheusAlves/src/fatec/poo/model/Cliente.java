
package fatec.poo.model;

/**
 *
 * @Matheus Alves
 */
public class Cliente extends Pessoa{
    private int numMesa;
    private double totalConta;
    
    public Cliente(int cod, String n, int nm){
        super(cod,n);
        numMesa = nm;
    }
    
    public void setTotalConta(double tc){
        totalConta = tc;
    }
    
    public int getNumMesa(){
        return(numMesa);
    }
    
    public double getTotalConta(){
        return(totalConta);
    }
    
        
}
