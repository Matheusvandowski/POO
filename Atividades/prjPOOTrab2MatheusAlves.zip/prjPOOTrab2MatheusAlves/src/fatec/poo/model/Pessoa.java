
package fatec.poo.model;

/**
 *
 * @Matheus Alves
 */
public class Pessoa {
   private int codigo; 
   private String nome;
   
   public Pessoa(int cod, String n){
       codigo = cod;
       nome = n;
   }
   
   public String getNome(){  
       return(nome);
   }
   
   public int getCodigo(){
       return(codigo);
   }
    
}
