
package fatec.poo.model;

/**
 *
 * @Matheus Alves
 */
public class Garcom extends Pessoa{
    private double salBase;
    private double taxaServico;
    private double totalGorjeta;

    public Garcom(int cod, String n, double ts) {
        super(cod, n);
        taxaServico = ts/100;
    }

      
    public void setSalBase(double sb){
        salBase = sb;
    }
    
    public double getSalBase(){
        return(salBase);
    }
    
    public double getTaxaServico(){
        return(taxaServico);
    }
    
    public void addGorjeta(double valContaCliente ){
        totalGorjeta = totalGorjeta + (valContaCliente*taxaServico);
    }
    
    public double getTotalGorjeta(){
        return(totalGorjeta);
    }
    
    public double calcSalFinal(){
        return(salBase + totalGorjeta);
    }
    
}
