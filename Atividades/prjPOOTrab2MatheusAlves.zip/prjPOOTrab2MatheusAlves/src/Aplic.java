
import fatec.poo.model.Cliente;
import fatec.poo.model.Garcom;
import java.text.DecimalFormat;
import java.util.Scanner;



/**
 *
 * @Matheus Alves
 */
public class Aplic {

    
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("0,000.00");
        Scanner entrada = new Scanner(System.in);
        
        String  nomeGarcom, nomeCliente1, nomeCliente2; 
        int codigoGarcom, codigoCliente1, codigoCliente2, numMesa1, numMesa2;
        double ts, conta1, conta2;
        
        System.out.println("Digite o código do Garçom:  ");
        codigoGarcom = entrada.nextInt();
        System.out.println("Digite o Nome do Garçom :  ");
        nomeGarcom = entrada.next();
        System.out.println("Digite a porcentagem de taxa do garçom (%):  ");
        ts = entrada.nextDouble();
        
        Garcom objGarcom = new Garcom(codigoGarcom, nomeGarcom, ts);
        
        System.out.println("Digite o código do Primeiro Cliente:  ");
        codigoCliente1 = entrada.nextInt();
        System.out.println("Digite o Nome do Primeiro Cliente :  ");
        nomeCliente1 = entrada.next();
        System.out.println("Digite a o Numero da mesa desse Cliente:  ");
        numMesa1 = entrada.nextInt();
        
        Cliente objCliente1 = new Cliente(codigoCliente1, nomeCliente1, numMesa1);
        
        
        System.out.println("Digite o código do Segundo Cliente:  ");
        codigoCliente2 = entrada.nextInt();
        System.out.println("Digite o Nome do Segundo Cliente :  ");
        nomeCliente2 = entrada.next();
        System.out.println("Digite a o Numero da mesa desse Cliente:  ");
        numMesa2 = entrada.nextInt();
        
        Cliente objCliente2 = new Cliente(codigoCliente2, nomeCliente2, numMesa2);
        
        System.out.println("Digite o valor de salário base do Garçom:  ");
        objGarcom.setSalBase(entrada.nextDouble());
        
        System.out.println("Digite o total da Conta da Mesa do Primeiro Cliente:  ");
        conta1 = entrada.nextDouble();
        objCliente1.setTotalConta(conta1);
         
        System.out.println("Digite o total da Conta da Mesa do Segundo Cliente:  ");
        conta2 = entrada.nextDouble();
        objCliente2.setTotalConta(conta2);
        
        objGarcom.addGorjeta(conta1);
        objGarcom.addGorjeta(conta2);
        
        
        System.out.println("Código Garçom: " + objGarcom.getCodigo());
        System.out.println("Nome Garçom: " + objGarcom.getNome());
        System.out.println("\nNum. Mesa: " + objCliente1.getNumMesa() + "\tTotal Conta: " + df.format(objCliente1.getTotalConta()));
        System.out.println("Num. Mesa: " + objCliente2.getNumMesa() + "\tTotal Conta: " + df.format(objCliente2.getTotalConta()));
        System.out.println("\nSalário: " + df.format(objGarcom.calcSalFinal()));
                
    }
    
}
