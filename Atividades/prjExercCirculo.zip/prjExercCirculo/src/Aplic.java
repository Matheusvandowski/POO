/**
 *
 * @author Murilo
 */
public class Aplic {
    public static void main(String[] args) {
        Circulo objCir;
        Circulo objCir1;
        
        //Instanciação (alocação) do objeto da classe retangulo
        objCir = new Circulo();
        objCir1 = new Circulo();
        
        //passagem de mensagem
        objCir.setRaio(1);
        objCir1.setRaio(2);
                        
        System.out.println("Medida do raio: " + objCir.getRaio());
        System.out.println("Medida da area: " + objCir.calcArea());
        System.out.println("Medida do perimetro: " + objCir.calcPerimetro());
        System.out.println("Medida do diametro: " + objCir.calcDiametro());
        
        System.out.println("\nMedida do raio: " + objCir1.getRaio());
        System.out.println("Medida da area: " + objCir1.calcArea());
        System.out.println("Medida do perimetro: " + objCir1.calcPerimetro());
        System.out.println("Medida do diametro: " + objCir1.calcDiametro());
    }
    
}
