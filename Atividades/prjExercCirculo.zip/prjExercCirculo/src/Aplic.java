
import java.util.Scanner;

/**
 *
 * @author Matheusvandowski
 */
public class Aplic {
    public static void main(String[] args) {
              
        
        String unidade;
        Scanner entrada = new Scanner(System.in);
        
        
        System.out.print("Digite a unidade de medida: ");
        unidade = entrada.next();
        
       Circulo objCir = new Circulo(unidade);
        
        //Instanciação (alocação) do objeto da classe retangulo
       
        //passagem de mensagem
        objCir.setRaio(1);
        
                        
        System.out.println("Medida do raio: " + objCir.getRaio()+ " " + objCir.getunidadeMedida());
        System.out.println("Medida da area: " + objCir.calcArea()+ " " + objCir.getunidadeMedida()+"²");
        System.out.println("Medida do perimetro: " + objCir.calcPerimetro()+ " " + objCir.getunidadeMedida());
        System.out.println("Medida do diametro: " + objCir.calcDiametro()+ " " + objCir.getunidadeMedida());
        
  
    }
    
}
