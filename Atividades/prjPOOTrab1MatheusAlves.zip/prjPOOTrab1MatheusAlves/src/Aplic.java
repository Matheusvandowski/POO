
import java.text.DecimalFormat;
import java.util.Scanner;



/**
 *
 * @Matheus Avles
 */
public class Aplic {

   
    public static void main(String[] args) {
        
        DecimalFormat df = new DecimalFormat("0.00");
        
        double coefA, coefB, coefC;
        
        Scanner entrada = new Scanner(System.in);      
        System.out.println("Digite o Coeficiente A: ");
        coefA = entrada.nextDouble();
        System.out.println("Digite o Coeficiente B: ");
        coefB = entrada.nextDouble();
        System.out.println("Digite o Coeficiente C: ");
        coefC = entrada.nextDouble();
        
        Equacao2Grau objEquacao = new Equacao2Grau(coefA, coefB, coefC);
        
        System.out.println("Equação: " + objEquacao.exibeEquacao());
        
        if(objEquacao.calcDelta() < 0 ){
        System.out.println("Não tem Raiz real");
        }
        else 
        if(objEquacao.calcDelta() > 0 ){
        System.out.println("Raiz: " + df.format(objEquacao.calcRaiz(1)));
        System.out.println("Raiz: " + df.format(objEquacao.calcRaiz(2)));        
        }
        else
        System.out.println("Raiz: " + df.format(objEquacao.calcRaiz(1)));
  
        }
    }
    

