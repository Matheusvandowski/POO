
import java.util.Scanner;



/**
 *
 * @author Matheusvandowski
 */
public class Aplic {

    
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        Aluno objAluno = new Aluno();
        
        double nota1, nota2, trab1, trab2; 
        int ra;
        
        
        System.out.println("Digite o RA do Aluno: ");
        ra = entrada.nextInt();
        System.out.println("Digite o valor da nota da primeira  do aluno: ");
        nota1 = entrada.nextDouble();
        System.out.println("Digite o valor da nota da segunda prova do aluno: ");
        nota2 = entrada.nextDouble();
        System.out.println("Digite o valor da nota do primeiro trabalho do aluno: ");
        trab1 = entrada.nextDouble();
        System.out.println("Digite o valor da nota do segundo trabalho do aluno: ");
        trab2 = entrada.nextDouble();
        
        objAluno.setRa(ra);
        objAluno.setNota1(nota1);
        objAluno.setNota2(nota2);
        objAluno.setTrab1(trab1);
        objAluno.setTrab2(trab2);
        
        System.out.println("RA do Aluno: " + objAluno.getRa());
        System.out.println("Nota Primeira Prova " + objAluno.getNota1());
        System.out.println("Nota Segunda Prova " + objAluno.getNota2());
        System.out.println("Nota Primeiro Trabalho" + objAluno.getTrab1());
        System.out.println("Nota Segundao Trabalho" + objAluno.getTrab2());
        
        
    }
    
}
