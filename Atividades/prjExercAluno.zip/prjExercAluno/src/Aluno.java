
package Aluno;

/**
 *
 * @author Matheusvandowski
 */
public class Aluno {
    
    private int ra; 
    
    private double nota1;
    
    private double nota2;
    
    private double trab1;
    
    private double trab2; 
    
    public void setNota1( double n1){
        nota1 = n1;    
}
    public double getNota1(){
        return(nota1);
    }
    
   public void setNota2 ( double n2){
       nota2 = n2;
   }
   
    public double getNota2(){
        return(nota2);
    }
    
    public void setRa( int r ){
       ra = r;
   }
   
    public int getRa(){
        return(ra);
    }
    
    public void setTrab1 ( double t1){
       trab1 = t1;
   }
   
    public double getTrab1(){
        return(trab1);
    }
    
      public void setTrab2 ( double t2){
       trab2 = t2;
   }
   
    public double getTrab2(){
        return(trab2);
    }
 
 public double calcMediaProva(){
     return( 0.75 * ( nota1 + 2 * nota2)/2);
}
 
 public double calcMediaTrab(){
     return( 0.25 * ( trab1 + trab2)/2);
    }
 
 public double calcMediaFinal(){
     return( calcMediaProva + calcMediaTrab);
 }
}