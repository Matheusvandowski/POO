
package fatec.poo.model;

/**
 *
 * @Matheusvandowski
 */
public class PessoaJuridica extends Pessoa {
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica ( String c, String n, int a){
        super(n,a);
        cgc = c;
    }
    
    public void setTaxaIncentivo(double ti){
        taxaIncentivo = ti/100;
    }
    
    public String getCGC(){
        return( cgc);
    }
    
    public double getTaxaIncentivo( ){
        return( taxaIncentivo);
    }
    
    @Override
    public double calcBonus( int anoAtual ){
        return((taxaIncentivo * getTotalCompras())* (anoAtual - getAnoInscricao()));
    }
}
