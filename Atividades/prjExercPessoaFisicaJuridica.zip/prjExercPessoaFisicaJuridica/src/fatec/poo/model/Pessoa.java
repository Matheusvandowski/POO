
package fatec.poo.model;

/**
 *
 * @Matheusvandowski 
 */
public abstract class Pessoa {
    private String nome;
    private int anoInscricao;
    private double totalCompras;
       
    public Pessoa ( String n, int a ){
        nome = n;
        anoInscricao = a;
    }
    
    abstract public double calcBonus(int i);
    
    public double addCompras(double a){
        totalCompras = totalCompras + a;
        return(totalCompras);
    }
    
    public String getNome(){
        return(nome);
    }
    
    public int getAnoInscricao(){
        return(anoInscricao);
    }
    
    public double getTotalCompras(){
        return(totalCompras);
    }
    
 }
