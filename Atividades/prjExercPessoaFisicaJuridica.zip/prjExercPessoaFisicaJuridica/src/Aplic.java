
import fatec.poo.model.PessoaFisica;
import fatec.poo.model.PessoaJuridica;



/**
 *
 * @Matheusvandowski 
 */
public class Aplic {

    
    public static void main(String[] args) {
        PessoaFisica pessFisic = new PessoaFisica("475.295.343-28", "Murilo Bertoni", 1997 );
        PessoaJuridica pessJurid = new PessoaJuridica("60.656.774/0001-05", "Alberflex Industria de Moveis", 1885);
        
        pessFisic.setBase(1500.00);
        pessFisic.addCompras(6000.00);
        pessFisic.addCompras(6500.00);
        
        pessJurid.setTaxaIncentivo(10);
        pessJurid.addCompras(5000.00);
        pessJurid.addCompras(9000.00);
        
        System.out.println("Nome: " + pessFisic.getNome());
        System.out.println("CPF: " + pessFisic.getCPF());
        System.out.println("Ano Inscrição: " + pessFisic.getAnoInscricao());
        System.out.println("Total Compras: " + pessFisic.getTotalCompras());
        System.out.println("Base: " + pessFisic.getBase());
        System.out.println("Valor do Bonus: " + pessFisic.calcBonus(2024));
        
        System.out.println("\nNome: " + pessJurid.getNome());
        System.out.println("CGC: " + pessJurid.getCGC());
        System.out.println("Ano Inscrição: " + pessJurid.getAnoInscricao());
        System.out.println("Total Compras: " + pessJurid.getTotalCompras());
        System.out.println("Taxa Incentivo: " + pessJurid.getTaxaIncentivo());
        System.out.println("Valor do Bonus: " + pessJurid.calcBonus(2024));
        
        
    }
    
}
