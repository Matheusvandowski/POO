

/**
 *
 * @author Matheusvandowski 
 */
public class Retangulo {
    
    private double altura;
    private double base;
    
    public void setBase ( double b){
        base = b;
    }
    
    public double getBase(){
        return(base);
    }
    
    public void setAltura ( double a){
        altura = a;
    }
    
     public double getAltura(){
        return(altura);
    }
    
    public double calcArea(){
        return(altura*base);
    }
    
    public double calcPerimetro(){
        return(2*(base+altura));
    }
}
