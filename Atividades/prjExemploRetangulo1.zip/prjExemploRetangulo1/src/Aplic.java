

/**
 *
 * @author Matheusvandowski
 */
public class Aplic {

    public static void main(String[] args) {
        // Def. Ponteiro 
        Retangulo objRet;
        
        //Instanciação(alocação) do objeto da classe Retangulo
       objRet =  new Retangulo();
        
        //passgem de mensagem
        objRet.setAltura(5.0);
        objRet.setBase(8.0);
        
        System.out.println("Medida da Area: " + objRet.calcArea());
        System.out.println("Medida do Perimetro: " + objRet.calcPerimetro());
        System.out.println("Medida da Altura: " + objRet.getAltura());
        
    }
    
}
