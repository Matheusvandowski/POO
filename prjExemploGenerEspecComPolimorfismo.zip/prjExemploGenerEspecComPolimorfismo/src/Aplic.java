
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;


/**
 *
 * @author Mvandowski 
 */
public class Aplic {

    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010,"Pedro Calvo","07/09/1985", 15.00);
        FuncionarioMensalista funcMen = new FuncionarioMensalista(2013,"Pedro Cabeludo", "20/08/2006", 1450.00);
        
        funcHor.setQtdHorTrab(44*4);
        funcMen.setNumSalMin(5);
        
        System.out.println("\nSalario Bruto: " + funcHor.calcSalBruto());
        System.out.println("\nValor Desconto: " + funcHor.calcDesconto());
        System.out.println("\nSalario Liquido: " + funcHor.calcSalLiquido());
        
        System.out.println("\n ");
        
        System.out.println("\nSalario Bruto: " + funcMen.calcSalBruto());
        System.out.println("\nValor Desconto: " + funcMen.calcDesconto());
        System.out.println("\nSalario Liquido: " + funcMen.calcSalLiquido());
        
        
    }
    
}
