
package fatec.poo.model;

import java.util.ArrayList;

/**
 *
 * @author 0030482313013
 */
public class Cliente extends Pessoa {

    ArrayList<Pedido>pedidos = new ArrayList<Pedido>();
    
    private double limiteCredito;
    private double limiteDisponivel;
    

    
    public Cliente(String cpf, String nome, double limiteCredito) {
        super(cpf, nome);
        this.limiteCredito = limiteCredito;
        this.limiteDisponivel = limiteCredito;
        
    }

    public void setLimiteCredito(double limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public void setLimiteDisponivel(double limiteDisponivel) {
        this.limiteDisponivel = limiteDisponivel;
    }

    public double getLimiteCredito() {
        return limiteCredito;
    }

    public double getLimiteDisponivel() {
        return limiteDisponivel;
    }
    
    public void addPedido(Pedido ped){ 
       this.pedidos.add(ped);
   }
    
    
    
}
