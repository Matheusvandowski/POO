
package fatec.poo.control;


import fatec.poo.model.Vendedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Murilo e Matheus
 */
public class DaoVendedor {
    private Connection conn;
    
    public DaoVendedor (Connection conn) {
         this.conn = conn;
    }    
    
    public Vendedor consultar (int ra) {
        Vendedor objVendedor = null;         
       
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("SELECT * from tblVendedor where Cpf_Cliente = ?");
            
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
           
            if (rs.next() == true) {
                objVendedor = new Vendedor(rs.getString("Cpf_Vendedor"),rs.getString("Nome_Vendedor"),rs.getDouble("SalarioBase_Vendedor"));
                
                objVendedor.setTaxaComissao(rs.getDouble("TaxaComissao_Vendedor"));
            }
        }
        catch (SQLException ex) { 
             System.out.println(ex.toString());   
        }
        return(objVendedor);
    }    
     
    public void inserir(Vendedor objVendedor) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("INSERT INTO tblAluno(Cpf_Vendedor, Nome_Vendedor, SalarioBase_Vendedor, TaxaComissao_Vendedor) VALUES(?,?,?,?)");
            ps.setString(1, objVendedor.getCpf());
            ps.setString(2, objVendedor.getNome());
            ps.setDouble(3, objVendedor.getSalarioBase());
            ps.setDouble(4, objVendedor.getTaxaComissao());
                      
            ps.execute(); //envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }  
    
    public void alterar(Vendedor vendedor) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("UPDATE tblVendedor set Nome_Vendedor = ?, " +
                                       "SalarioBase_Vendedor = ?, " +
                                       "TaxaComissao_Vendedor = ? " +
                                       "where Cpf_Vendedor = ?");
            
            ps.setString(1, vendedor.getNome());
            ps.setDouble(2, vendedor.getSalarioBase());
            ps.setDouble(3, vendedor.getTaxaComissao());
            ps.setString(4, vendedor.getCpf());
           
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
    
    public void excluir(Vendedor vendedor) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM tblCliente where Cpf_Cliente = ?");
            
            ps.setString(1, vendedor.getCpf());
                      
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
}
