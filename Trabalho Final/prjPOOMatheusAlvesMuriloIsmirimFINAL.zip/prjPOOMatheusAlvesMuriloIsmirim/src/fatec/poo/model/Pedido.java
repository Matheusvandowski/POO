
package fatec.poo.model;

/**
 *
 * @Mvandowski
 */
public class Pedido {
    private String numero;
    private String dataNumero;
    private double valor;
    
    public Pedido(String numero) {
        this.numero = numero;
        
    }

    public void setDataNumero(String dataNumero) {
        this.dataNumero = dataNumero;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDataNumero() {
        return dataNumero;
    }

    public double getValor() {
        return valor;
    }

    public String getNumero() {
        return numero;
    }
    
    

   
    
}
