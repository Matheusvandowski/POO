
package fatec.poo.control;


import fatec.poo.model.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Murilo e Matheus 
 */
public class DaoPedido {
    private Connection conn;
    
    public DaoPedido(Connection conn) {
         this.conn = conn;
    }    
    
    public Pedido consultar (String numero) {
        Pedido objPedido = null;         
       
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("SELECT * from tblPedido where Numero_Pedido = ?");
            
            ps.setString(1, numero);
            ResultSet rs = ps.executeQuery();
           
            if (rs.next() == true) {
                objPedido = new Pedido(rs.getString("Numero_Pedido"));
                objPedido.setDataNumero(rs.getString("DataEmissao_Pedido"));
                objPedido.setValor(rs.getDouble("Valor_Pedido"));
            }
        }
        catch (SQLException ex) { 
             System.out.println(ex.toString());   
        }
        return(objPedido);
    }    
     
    public void inserir(Pedido objPedido) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("INSERT INTO tblAluno(Numero_Pedido, DataEmissao_Pedido, Valor_Pedido) VALUES(?,?,?)");
            ps.setString(1, objPedido.getNumero());
            ps.setString(2, objPedido.getDataNumero());
            ps.setDouble(3, objPedido.getValor());
                                  
            ps.execute(); //envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }  
    
    public void alterar(Pedido pedido) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("UPDATE tblPedido set Numero_Pedido = ?, " +
                                       "DataEmissao_Pedido = ?, " +
                                       "Valor_Pedido = ? " +
                                       "where Numero_Pedido = ?");
            
            ps.setString(1, pedido.getNumero());
            ps.setString(2, pedido.getDataNumero());
            ps.setDouble(3, pedido.getValor());           
           
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
    
    public void excluir(Pedido pedido) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM tblPedido where Numero_Pedido = ?");
            
            ps.setString(1, pedido.getNumero());
                      
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
}
