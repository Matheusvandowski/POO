package fatec.poo.control;

import fatec.poo.model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Matheus e Murilo 
 */
public class DaoCliente {
    private Connection conn;
    
    public DaoCliente (Connection conn) {
         this.conn = conn;
    }    
    
    public Cliente consultar (String cpf) {
        Cliente objCliente = null;         
       
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("SELECT * from tblCliente where Cpf_Cliente = ?");
                      
            
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
           
            if (rs.next() == true) {
                objCliente = new Cliente(rs.getString("Cpf_Cliente"),rs.getString("Nome_Cliente"), rs.getDouble("LimiteDisponivel_Cliente"));
                objCliente.setLimiteDisponivel(rs.getDouble("LimiteDisponivel_Cliente"));
            }
        }
        catch (SQLException ex) { 
             System.out.println(ex.toString());   
        }
        return(objCliente);
    }    
     
    public void inserir(Cliente objCliente) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("INSERT INTO tblAluno(Cpf_Cliente, Nome_Cliente, LimiteCredito_Cliente, LimiteDisponivel_Cliente) VALUES(?,?,?,?)");
            ps.setString(1, objCliente.getCpf());
            ps.setString(2, objCliente.getNome());
            ps.setDouble(3, objCliente.getLimiteCredito());
            ps.setDouble(4, objCliente.getLimiteDisponivel());
                      
            ps.execute(); //envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }  
    
    public void alterar(Cliente cliente) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("UPDATE tblCliente set Nome_Cliente = ?, " +
                                       "LimiteCredito_Cliente = ?, " +
                                       "LimiteDisponivel_Cliente = ? " +
                                       "where Cpf_Cliente = ?");
            
            ps.setString(1, cliente.getNome());
            ps.setDouble(2, cliente.getLimiteCredito());
            ps.setDouble(3, cliente.getLimiteCredito());
            ps.setString(4, cliente.getCpf());
           
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
    
    public void excluir(Cliente cliente) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM tblCliente where Cpf_Cliente = ?");
            
            ps.setString(1, cliente.getCpf());
                      
            ps.execute(); //Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
}
