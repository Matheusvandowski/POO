/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.control;

import fatec.poo.model.Aluno;
import fatec.poo.model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author matheusvandowski
 */
public class DaoCliente {
    private Connection conn; 
    
    public DaoCliente(Connection conn){
        this.conn = conn; 
    }
    
    public Cliente consultar ( String cpf){
        Cliente objCliente = null;
        
        PreparedStatement ps;
        
        try{
            ps = conn.prepareStatement("SELECT * from tblCliente where Cpf_Cli = ?");
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next() == true) {
                objCliente = new Cliente(rs.getString("Cpf_Cli"),rs.getString("Nome_Cli"));
                objCliente.setLimCred(rs.getDouble("LimCred_Cli"));
                objCliente.setLimCredDisp(rs.getDouble("LimCredDisp_Cli");
        }
            
        catch(SQLException ex){
                System.out.println(ex.toString());
        }
        return(objCliente);
    }    
            
    }
    
    public void inserir (Cliente objCliente){
        PreparedStatement ps;
        
        try{
            ps = conn.prepareStatement("INSERT INTO tblCliente(Cpf_Cli, Nome_Cli, LimCred_Cli, LimCredDisp_Cli) VALUES(?,?,?,?)");
            ps.setString(1, objCliente.getCpf());
            ps.setString(2, objCliente.getNome());
            ps.setDouble(3, objCliente.getLimCred());
            ps.setDouble(4, objCliente.getLimCredDisp());
                      
            ps.execute(); //envia a instrução SQL para o SGBD
        }
        catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
}
    
   